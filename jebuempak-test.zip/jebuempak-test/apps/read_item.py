def main( args ):
	print( type( args ) )
	item_id = args.item_id
	q = args.q

	return  {"item_id": item_id, "q": q}