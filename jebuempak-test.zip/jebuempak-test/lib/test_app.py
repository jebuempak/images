def app(self):
		return self.app