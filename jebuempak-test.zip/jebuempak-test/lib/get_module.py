import sys


class dict2obj(object):
	def __init__(self, d):
		self.__dict__['d'] = d

	def __getattr__(self, key):
		value = self.__dict__['d'][key]
		if type(value) == type({}):
			return dict2obj(value)
		return value
		
class Getattring:
	def __init__(self):
		pass
	
	def modGetattr(self):
		argv = sys._getframe(1).f_locals
		f = sys._getframe(1).f_code
		#print( f.co_varnames[0:f.co_argcount])
		_v = f.co_varnames[0:f.co_argcount]
		funcName = f.co_name
		_modName = "apps.{0}".format(funcName)
		modName = __import__(_modName, fromlist=[_modName])
		data = getattr(modName, 'main')(dict2obj(argv))
		return data
	
	""" 
	def modGetattr(self):
		argv = sys._getframe(1).f_locals
		f = sys._getframe(1).f_code
		print( "Check ========================================================== > 1")
		print( "co_argcount			: ", f.co_argcount )
		print( "co_cellvars			: ", f.co_cellvars )
		print( "co_code				: ", f.co_code )
		print( "co_consts         	: ", f.co_consts )
		print( "co_filename        	: ", f.co_filename )
		print( "co_firstlineno     	: ", f.co_firstlineno )
		print( "co_flags     		: ", f.co_flags )
		print( "co_freevars     	: ", f.co_freevars )
		print( "co_kwonlyargcount   : ", f.co_kwonlyargcount )
		print( "co_lines     		: ", f.co_lines )
		print( "co_linetable     	: ", f.co_linetable )
		print( "co_lnotab     		: ", f.co_lnotab )
		print( "co_name     		: ", f.co_name )
		print( "co_names     		: ", f.co_names )
		print( "co_nlocals     		: ", f.co_nlocals )
		print( "co_posonlyargcount 	: ", f.co_posonlyargcount )
		print( "co_stacksize       	: ", f.co_stacksize )
		print( "co_varnames     	: ", f.co_varnames )
		print( "replace       		: ", f.replace )
		print( f.co_varnames[0:f.co_argcount])
		#print( dir(f.replace) )
		print( "Check ========================================================== < 1")
		_v = f.co_varnames[0:f.co_argcount]
		funcName = f.co_name
		_modName = "apps.{0}".format(funcName)
		modName = __import__(_modName, fromlist=[_modName])
		
		
		data = getattr(modName, 'main')(argv) #(*args)
		return data
	 """