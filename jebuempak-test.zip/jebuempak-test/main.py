from ast import arg
import sys
from typing import Optional
from fastapi import FastAPI

from pydantic import BaseModel
import time

from lib import get_module
app = FastAPI()

getModule = get_module.Getattring() 

class Item(BaseModel):
	name: str
	price: float
	is_offer: Optional[bool] = None
	
@app.get("/")
async def index():
	rst = getModule.modGetattr()
	return rst

@app.get("/items/{item_id}")
def read_item(item_id: int, q: Optional[str] = None):
	rst = getModule.modGetattr()
	return rst

#@app.get("/items/{item_id}")
#async def read_item(item_id: int, q: Optional[str] = None):
#	return {"item_id": item_id, "q": q}

@app.get("/jebuempak/{item_id}")
async def test(item_id: int):
	for x in range(10):
		item_id = item_id + 3
	print( item_id )
	return item_id

@app.put("/items/{item_id}")
def update_item(item_id: int, item: Item):
    return {"item_name": item.name, "item_id": item_id}